import os
from flask import Flask, render_template, jsonify, request

from uspstf_knowledgebase import KOs

app = Flask(__name__)



@app.route("/")
def index():
    # Render the HTML page with patient data
    return render_template("index.html")

@app.route("/get_result", methods=["POST"])
def get_result():
    patient_data = request.get_json()
    result={}
    for ko in KOs:
        result[ko.get_id()] = ko.execute(patient_data)
    
    return jsonify(result)

if __name__ == "__main__":
    port = int(os.environ.get('PORT', 5000))
    app.run(host='0.0.0.0', port=port,debug=True)
    
# export FLASK_APP=sdk_demo.app:app 
# flask run 
 