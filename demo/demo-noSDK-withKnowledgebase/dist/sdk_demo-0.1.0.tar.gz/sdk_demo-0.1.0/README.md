## Run 
To run this app locally, set the environment variable FLASK_APP with the path to the Flask app definition and execute the Flask app as following
```bash
export FLASK_APP=sdk_demo.app:app 
flask run 
```
Then, access the demo app at http://127.0.0.1:5000 in your browser.
