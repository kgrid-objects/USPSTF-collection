from .diabetes_screening import diabetes_screening
from .diabetes_screening import apply