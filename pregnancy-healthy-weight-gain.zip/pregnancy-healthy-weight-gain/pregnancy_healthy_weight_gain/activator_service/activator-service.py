from ..knowledge import get_pregnancy_healthy_weight_gain_recommendation

def apply(input):
    return get_pregnancy_healthy_weight_gain_recommendation(input["pregnant"])

